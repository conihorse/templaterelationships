This is the template file set for template Coffees( 6f28715f-d054-4dd9-802d-fb84560df17a, revision 1), exported from the Clinical Knowledge Manager.
Export time: Wed Dec 12 12:12:36 MST 2018