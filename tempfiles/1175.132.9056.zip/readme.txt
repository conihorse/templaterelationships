This is the template file set for template Drinks Menu( 147749ce-b25b-4be2-9dd4-661cc54a6aa7, revision 1), exported from the Clinical Knowledge Manager.
Export time: Wed Dec 12 12:12:41 MST 2018