This is the template file set for template Menu Morning( c5a34cc5-cc9b-4964-8479-1cf336dd7d57, revision 2), exported from the Clinical Knowledge Manager.
Export time: Tue Dec 11 16:01:44 MST 2018